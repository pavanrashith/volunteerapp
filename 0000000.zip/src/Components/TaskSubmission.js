import React from 'react'
import '../../src/styles.css';
import GraduateHeader from './GraduateHeader';

function TaskSubmission() {
  return (
<>
<GraduateHeader/>
<main className="container">
    <section className="task-form">
        <h2>Submit Task</h2>
        <form>
            <label for="taskName">Task Name:</label>
            <input type="text" id="taskName" name="taskName"/>
            
            <label for="deadline">Deadline:</label>
            <input type="date" id="deadline" name="deadline"/>
            
            <label for="priority">Priority:</label>
            <select id="priority" name="priority">
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
            </select>
            
            <button type="submit">Submit Task</button>
        </form>
    </section>
</main>

<footer>
    <p>&copy; 2024 Task Submission. All rights reserved.</p>
</footer>
</>  )
}

export default TaskSubmission