import React, { useState } from 'react';
import GraduateHeader from './GraduateHeader';
function WeeklyReports() {
    const [summary, setSummary] = useState('');
    const [attachments, setAttachments] = useState([]);

    const handleSummaryChange = (e) => {
        setSummary(e.target.value);
    };

    const handleAttachmentsChange = (e) => {
        setAttachments([...e.target.files]);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Handle form submission (e.g., send data to server)
        console.log('Summary:', summary);
        console.log('Attachments:', attachments);
    };
  return (
    <div>
            <GraduateHeader/>

            <h2>Weekly Report Submission</h2>
            <form onSubmit={handleSubmit}>
                <label htmlFor="workSummary">Summary of Work (21 hours)</label>
                <textarea id="workSummary" value={summary} onChange={handleSummaryChange} required></textarea>
                <label htmlFor="attachments">Attachments</label>
                <input type="file" id="attachments" multiple onChange={handleAttachmentsChange} />
                <input type="submit" value="Submit" />
            </form>
        </div>
  )
}

export default WeeklyReports