import React from 'react'
import Header from './Header'

function ContactUs() {
  return (
<>
<Header/>
<div className='contact'>
 <div className='flex-container'>
  <div className='flex-item'>
 <div className='contactus'> 
   
      <h2>Contact Us</h2>
      <div className='contact-wrapper'>
    <div className='form-group'>
      <input type='text' placeholder='Name'/>
    </div>
    <div className='form-group'>
      <input type='text' placeholder='Email'/>
    </div>
    <div className='form-group'>
      <input type='text' placeholder='Company'/>
    </div>
    <div className='form-group'>
      <textarea placeholder='Message'></textarea>
    </div>
    <div className='form-group'>
      <button>Submit</button>
    </div>
    </div>
    </div>
    </div>
    <div className='flex-item'>
    <div className='help'>
      <h3>How can we help?</h3>
      <img src='https://getfullyfunded.com/wp-content/uploads/2018/12/volunteer-small.jpg' alter='img' style={{width:"100%"}}/>
    </div>
    </div>
  </div>
  </div>
</>
  )
}

export default ContactUs