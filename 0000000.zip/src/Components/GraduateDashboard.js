import React, { useEffect, useRef } from 'react';
import '../../src/styles.css';
import GraduateHeader from './GraduateHeader';
import FullCalendar from '@fullcalendar/react'; // Import the FullCalendar component
import dayGridPlugin from '@fullcalendar/daygrid'; // Import the dayGrid plugin
import { Bar } from 'react-chartjs-2';
import Chart from 'chart.js/auto';

function GraduateDashboard() {
    const weeklyReportsData = [
        { week: 1, progress: 60 },
        { week: 2, progress: 80 },
        { week: 3, progress: 80 }
        
    ];

    useEffect(() => {
        const weeklyReportsContainer = document.getElementById('weeklyReports');

        weeklyReportsData.forEach(function (weekData) {
            const weekContainer = document.createElement('div');
            weekContainer.classList.add('weekly-report-item');

            const weekHeading = document.createElement('h3');
            weekHeading.textContent = `Week ${weekData.week}`;

            const progressText = document.createElement('p');
            progressText.textContent = `Progress: ${weekData.progress}%`;

            weekContainer.appendChild(weekHeading);
            weekContainer.appendChild(progressText);

            weeklyReportsContainer.appendChild(weekContainer);
        });

        return () => {
            // Cleanup code to remove the weekly report items
            weeklyReportsContainer.innerHTML = '';
        };
    }, [weeklyReportsData]);

    const percent = 50; // Define the percent value here
    const radius = 100;
    const circumference = 2 * Math.PI * radius;
    const strokeDasharray = `${circumference}`;
    const strokeDashoffset = `${circumference - (circumference * percent) / 100}`;

    const circleStyle = {
        strokeDasharray,
        strokeDashoffset
    };

    const progressData = weeklyReportsData.map(weekData => weekData.progress);
    const progressLabels = weeklyReportsData.map(weekData => `Week ${weekData.week}`);

    const chartData = {
        labels: [...progressLabels, "Total Tasks Completed", "Total Hours Worked", "Upcoming Deadlines"],
        datasets: [{
            label: 'Progress',
            data: [...progressData, 10, 100, 0], // Add total tasks completed, total hours worked, and upcoming deadlines
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            borderColor: 'rgba(75, 192, 192, 1)',
            borderWidth: 1
        }]
    };

    const chartOptions = {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    };

    const canvasRef = useRef(null);

    useEffect(() => {
        const ctx = canvasRef.current.getContext('2d');
        const chart = new Chart(ctx, {
            type: 'bar',
            data: chartData,
            options: chartOptions
        });

        return () => {
            // Cleanup code to destroy the chart instance
            chart.destroy();
        };
    }, [chartData, chartOptions]);

    return (
        <>
            <GraduateHeader />

            <main>
                <div className="progress-tracking">
                    <h2>Progress Tracking</h2>
                    <section className="flex-container">
                        <div className="box1 flex-item">
                            <div className="percent">
                                <svg>
                                    <circle cx="105" cy="105" r="100"></circle>
                                    <circle cx="105" cy="105" r="100" style={{ strokeDasharray: '628', strokeDashoffset: '440' }}></circle>
                                </svg>
                                <div className="number">
                                    <h3>30<span>/100</span></h3>
                                </div>
                            </div>
                            <div className="title">
                                <h2>Tasks Completed</h2>
                            </div>
                        </div>
                        <div className="box1">
                            <div className="percent">
                                <svg>
                                    <circle cx="105" cy="105" r="100"></circle>
                                    <circle cx="105" cy="105" r="100" style={{ strokeDasharray, strokeDashoffset }}></circle>
                                </svg>
                                <div className="number">
                                    <h3>3<span>/7</span></h3>
                                </div>
                            </div>
                            <div className="title">
                                <h2>Weeks</h2>
                            </div>
                        </div>
                        <div className="box1">
                            <div className="percent">
                                <svg>
                                    <circle cx="105" cy="105" r="100"></circle>
                                    <circle cx="105" cy="105" r="100" style={{ strokeDasharray: '628', strokeDashoffset: '125' }}></circle>
                                </svg>
                                <div className="number">
                                    <h3>100<span></span></h3>
                                </div>
                            </div>
                            <div className="title">
                                <h2>Hours Worked</h2>
                            </div>
                        </div>
                    </section>
                </div>
                <section className="calendar">
                    <h3>Task Calendar</h3>
                    <FullCalendar
    plugins={[dayGridPlugin]}
    initialView="dayGridMonth"
    events={[
        { title: 'Task 1', date: '2024-03-01' },
        { title: 'Task 2', date: '2024-03-08' },
        { title: 'Task 3', date: '2024-03-15' },
        
    ]}
    height="auto" // Set the height to auto to adjust based on content
    aspectRatio={2} // Set the aspect ratio to 2 (width:height) to control the width
/>
                </section>
                <div className="flex-container">
                <section className="weekly-reports ">
                        <h2>Weekly Reports</h2>
                        <div id="weeklyReports"></div>
                    </section>
                    <canvas ref={canvasRef} className="flex-item"></canvas>
                </div>
                
            </main>
            <footer>
                <p>&copy; 2024 Graduate Dashboard. All rights reserved.</p>
            </footer>
        </>
    )
}

export default GraduateDashboard;
