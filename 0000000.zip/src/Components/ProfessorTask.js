import React from 'react';
import '../styles.css'; // Assuming you have a styles.css file for styling
import ProfessorHeader from './ProfessorHeader';

function ProfessorTask() {
    return (
        <div>
            <ProfessorHeader/>
            <main className="container">
                <section className="task-assignment">
                    <form action="assign_task.php" method="post">
                        <label htmlFor="task">Task:</label>
                        <input type="text" id="task" name="task" required />
                        <label htmlFor="deadline">Deadline:</label>
                        <input type="date" id="deadline" name="deadline" required />
                        <label htmlFor="priority">Priority:</label>
                        <select id="priority" name="priority">
                            <option value="high">High</option>
                            <option value="medium">Medium</option>
                            <option value="low">Low</option>
                        </select>
                        <button type="submit">Assign Task</button>
                    </form>
                </section>
            </main>
            <footer>
                <p>&copy; 2024 Professor's Dashboard. All rights reserved.</p>
            </footer>
        </div>
    );
}

export default ProfessorTask;
