import React from 'react'
import '../../src/styles.css';
import GraduateHeader from './GraduateHeader';
import FullCalendar from '@fullcalendar/react'; // Import the FullCalendar component
import dayGridPlugin from '@fullcalendar/daygrid'; // Import the dayGrid plugin

function GraduateCalendar() {
  return (
    <>
    <GraduateHeader/>
    <header>
    <h1>Calendar</h1>
</header>

<main className="container">
    <section className="calendar">
        <h2>Calendar</h2>
        <FullCalendar
            plugins={[dayGridPlugin]}
            initialView="dayGridMonth"
            events={[
                { title: 'Event 1', date: '2024-03-01' },
                { title: 'Event 2', date: '2024-03-05' }
            ]}
        />
    </section>
</main>

<footer>
    <a href="progress.html">View Progress</a>
    <a href="weekly_reports.html">View Weekly Reports</a>
</footer>
</>
  )
}

   

export default GraduateCalendar