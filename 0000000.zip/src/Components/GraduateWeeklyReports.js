import React, { useState } from 'react';
import GraduateHeader from './GraduateHeader';

function GraduateWeeklyReports() {
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [file, setFile] = useState(null);

    const handleSubmit = (event) => {
        event.preventDefault();
        const fileInput = document.getElementById('attachment');
        const uploadedFile = fileInput.files[0];
        if (!uploadedFile) {
            return;
        }

        setFile(uploadedFile);
        setIsSubmitted(true);
    };

    return (
        <>
        <GraduateHeader/>
            {/* Your header and other content */}
            <main className="container">
                <section className="weekly-reports">
                    <h2>Weekly Reports</h2>
                    <form id="weeklyReportForm" onSubmit={handleSubmit}>
                        <textarea id="reportText" placeholder="Enter your Justification here..."></textarea>
                        <input type="file" id="attachment" accept=".pdf,.doc,.docx" />
                        <button type="submit">Submit Report</button>
                    </form>
                    {isSubmitted && file && (
                        <div>
                            <p>Submitted!</p>
                            <p>File uploaded: <a href={URL.createObjectURL(file)} target="_blank" rel="noreferrer">View File</a></p>
                        </div>
                    )}
                </section>
            </main>
            {/* Your footer */}
        </>
    );
}

export default GraduateWeeklyReports;
