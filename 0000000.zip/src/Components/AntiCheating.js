import React from 'react';

const AntiCheating = () => {
    return (
        <div>
            <h2>Anti-Cheating Mechanism</h2>
            <p>Implementing measures to prevent cheating in reports.</p>
        </div>
    );
};

export default AntiCheating;
