import React from 'react';
import Header from './Header';
import '../../src/style.css';

function Services() {
  return (
    <>
      <Header />
      <h3 style={{ textAlign: "center" }}>Services</h3>
      <section className="middle">
        <div className="flex-container">
          <div className="flex-item">
            <img src="https://www.cflowapps.com/wp-content/uploads/2018/07/task-management-process.png" alt="Image 1" className="service-image" />
            <h3>Task Management</h3>
            <p>Streamline task assignment, tracking, and completion for volunteers.</p>
          </div>
          <div className="flex-item">
            <img src="https://clipart-library.com/image_gallery/n697560.png" alt="Image 2" className="service-image" />
            <h3>Weekly Reports</h3>
            <p>Facilitate progress tracking and performance evaluation through weekly reports.</p>
          </div>
          <div className="flex-item">
            <img src="https://i.pinimg.com/originals/e8/0e/7f/e80e7f736033c1a3ab8846731f9c33d3.png" alt="Image 3" className="service-image" />
            <h3>Task Calendar</h3>
            <p>Organize volunteer activities and deadlines with task calendars.</p>
          </div>
          <div className="flex-item">
            <img src="https://image.freepik.com/free-vector/people-volunteers-illustration_95397-60.jpg" alt="Image 4" className="service-image" />
            <h3>Volunteer Support</h3>
            <p>Provide guidance and assistance to volunteers throughout their experience.</p>
          </div>
        </div>
      </section>
    </>
  );
}

export default Services;
