import React from 'react'
import '../../src/styles.css';
import GraduateHeader from './GraduateHeader';

function TaskView() {
  return (
<>

<GraduateHeader/>
<main className="container">
    <div className="flex-container">
        <div className="flex-item">
    <section className="task-list">
        <h2>Assigned Tasks</h2>
        <ul>
            <li>
                <h3>Task 1: Project Proposal</h3>
                <p><strong>Description:</strong> Prepare a project proposal outlining the objectives, scope, and deliverables.</p>
                <p><strong>Deadline:</strong> March 15, 2024</p>
                <p><strong>Priority:</strong> High</p>
            </li>
            <li>
                <h3>Task 2: Research Report</h3>
                <p><strong>Description:</strong> Conduct research on the latest industry trends and compile a detailed report.</p>
                <p><strong>Deadline:</strong> March 20, 2024</p>
                <p><strong>Priority:</strong> Medium</p>
            </li>
        </ul>
    </section>
</div>
<div className="flex-item">
    <img src="https://www.shutterstock.com/image-vector/project-coordinator-assigning-tasks-managing-600nw-2308243843.jpg" alt="" width="100%"/>
</div>
</div>
</main>

<footer>
    <p>&copy; 2024 Task Management. All rights reserved.</p>
</footer>

</>

    )
}

export default TaskView