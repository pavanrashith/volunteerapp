import React from 'react'
import '../../src/styles.css';
import GraduateHeader from './GraduateHeader';

function TaskStatusUpdates() {
  return (
   <>
<GraduateHeader/>

<main className="container">
    <section className="task-update-form">
        <h2>Mark Task as Complete</h2>
        <form>
            <label for="task">Task:</label>
            <select id="task" name="task">
                <option value="task1">Task 1</option>
                <option value="task2">Task 2</option>
            </select>
            <label for="status">Status:</label>
            <select id="status" name="status">
                <option value="complete">Complete</option>
                <option value="in-progress">In Progress</option>
            </select>
            <label for="comments">Comments:</label>
            <textarea id="comments" name="comments" rows="4" cols="50"></textarea>
            <button type="submit">Submit</button>
        </form>
    </section>
</main>

<footer>
    <p>&copy; 2024 Task Management. All rights reserved.</p>
</footer>
</>
  )
}

export default TaskStatusUpdates