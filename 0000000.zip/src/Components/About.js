import React from 'react';
import Header from './Header';

function AboutUs() {
  return (
    <div>
      <Header/>
      <div className='container'>
        
      <h2>About Us</h2>
      <p>
        Given the difficulties of the economy, many students find themselves trapped without a job after graduation. 
        In order to protect our international students, the government has designed a volunteer program. 
        This program runs under each one of our departments. Professors have to agree to supervise volunteers 
        and report their performance to the department and to immigration. Once students find a job, they are 
        released from the portal. Volunteering is a serious task. It requires a supervisor, a task to be researched 
        or implemented, 21 hours of weekly work, and a weekly report. It is also a volunteer activity for professors 
        to participate in.
      </p>
      <div className='flex-container'>
<img src='https://i.pinimg.com/originals/e8/0e/7f/e80e7f736033c1a3ab8846731f9c33d3.png' style={{width:"50%"}} className='flex-item'/>
<img src='https://clipart-library.com/image_gallery/n697560.png' style={{width:"50%"}} className='flex-item' />
</div>
      </div>
    </div>
  );
}

export default AboutUs;
