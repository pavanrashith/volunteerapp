import React, { useEffect } from 'react';
import '../../src/Components/home.css';
import Header from './Header';
// import Header from './Header';

function Home() {

    return (
        <>
           {/* <Header/> */}
           <div className="page-container">

		<Header/>


        
		<div className="rows rows-3">
			<div className="rows-content">
				<div className="cols cols-1 cols-w6">
					<div className="block block-2 heading">
						<h1
							style={{color:"#201f42",fontFamily:'Noto Serif , Georgia', fontSize:"28px",fontWeight:"700",letterSpacing:"normal",lineHeight:"120%",textAlign:"left",marginTop:"0",marginBottom:"0"}}>
							<span className="tinyMce-placeholder">VOLUGRAD : A place where graduate does volunteering, specially designed for international students who don't have a job after graduating</span> </h1>
					</div>
					<div className="block block-3 image desktop_hide"><img alt="" className="center autowidth"
							src="images/AdobeStock_365849380.jpeg" style={{maxWidth:"612px"}} /></div>
					
					</div>
				
				</div>
				
			</div>
		
		<div className="rows rows-5">
			<div className="rows-content">
				<div className="cols cols-1 cols-w12">
					<div className="block block-1 heading">
						<h2
style={{color:"#4f5aba",direction:"ltr",fontFamily:"Noto Serif", fontSize:"48px",fontWeight:"700",letterspacing:"normal",lineHeight:"120%",textalign:"left",marginTop:"0",marginBottom:"0"}}>
							<span className="tinyMce-placeholder">How you can contribute?</span> </h2>
					</div>
				</div>
			</div>
		</div>
		<div className="rows rows-6">
			<div className="rows-content">
				<div className="cols cols-1 cols-w4">
					<div className="block block-1 icons">
						<div className="icon icon-last">
							<div className="icon-image"><img height="32px" src="images/check.png" width="auto" /></div>
							<div className="icon-label icon-label-bottom">Become a volunteer</div>
						</div>
					</div>
					<div className="block block-2 paragraph">
						<p>Join our volunteer program and make a difference in the lives of our international students. Your commitment can help shape their future.</p>

					</div>
					<div className="block block-3 button">
            <a
                className="button-content"
                href="/contact"
                style={{
                    wordBreak: 'break-word',
                    fontSize: '16px',
                    lineHeight: '200%'
                }}
                target="_self"
            >
                Become A Volunteer
            </a>
        </div>
				</div>
				<div className="cols cols-2 cols-w4">
					<div className="block block-1 icons">
						<div className="icon icon-last">
							<div className="icon-image"><img height="32px" src="images/check.png" width="auto" /></div>
							<div className="icon-label icon-label-bottom">Get in touch with us</div>
						</div>
					</div>
					<div className="block block-2 paragraph">
						<p>Have questions or want to learn more about our volunteer opportunities? Reach out to us, and we'll be happy to provide you with more information.</p>

					</div>
                    <div className="block block-3 button">
            <a
                className="button-content"
                href="contact"
                style={{
                    fontSize: '16px',
                    backgroundcolor: 'transparent',
                    borderBottom: '2px solid #201F42',
                    borderLeft: '2px solid #201F42',
                    borderRadius: '0px',
                    borderRight: '2px solid #201F42',
                    borderTop: '2px solid #201F42',
                    color: '#201f42',
                    direction: 'ltr',
                    fontFamily: "'Noto Serif', Georgia, serif",
                    fontWeight: '400',
                    maxWidth: '100%',
                    paddingBottom: '5px',
                    paddingLeft: '30px',
                    paddingRight: '30px',
                    paddingTop: '5px',
                    width: 'auto',
                    display: 'inline-block'
                }}
                target="_self"
            >
                <span style={{ wordBreak: 'break-word', fontSize: '16px', lineHeight: '200%' }}>
                    Get in Touch »
                </span>
            </a>
        </div>				</div>
				<div className="cols cols-3 cols-w4">
					<div className="block block-1 icons">
						<div className="icon icon-last">
							<div className="icon-image"><img height="32px" src="images/check.png" width="auto" /></div>
							<div className="icon-label icon-label-bottom">Spread the word</div>
						</div>
					</div>
					<div className="block block-2 paragraph">
						<p>Help us spread awareness about our volunteer program. Share our mission with your friends, family, and community to encourage more people to get involved.</p>

					</div>
					<div className="block block-3 social">
						<div className="content"><span className="icon" style={{padding:"0 2.5px 0 2.5px"}}><a
									href="https://www.facebook.com" target="_self"><img alt="facebook"
										src="images/facebook2x.png" title="facebook" /></a></span><span className="icon"
								style={{padding:"0 2.5px 0 2.5px"}}><a href="https://www.twitter.com" target="_self"><img
										alt="twitter" src="images/twitter2x.png" title="twitter" /></a></span><span
								className="icon" style={{padding:"0 2.5px 0 2.5px"}}><a href="https://www.linkedin.com"
									target="_self"><img alt="linkedin" src="images/linkedin2x.png"
										title="linkedin" /></a></span><span className="icon"
								style={{padding:"0 2.5px 0 2.5px"}}><a href="https://www.instagram.com" target="_self"><img
										alt="instagram" src="images/instagram2x.png" title="instagram" /></a></span>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div className="rows rows-8">
			<div className="rows-content reverse">
				<div className="cols cols-1 cols-w6">
					<div className="block block-1 heading">
						<h3
							style={{color:"#201f42",direction:"ltr",fontFamily:"Noto Serif", fontSize:"24px",fontWeight:"700",letterspacing:"normal",lineHeight:"120%",textalign:"left",marginTop:"0",marginBottom:"0"}}>
							<span className="tinyMce-placeholder">How we help?</span> </h3>
					</div>
					<div className="block block-2 paragraph">
						<p>At our organization, we are dedicated to making a meaningful impact in higher education. Through our various initiatives, we strive to provide valuable support and resources to students pursuing their academic aspirations. </p>
					</div>
					<div className="block block-3 heading">
						<h3
							style={{color:"#4f5aba",direction:"ltr",fontFamily:"Noto Serif", fontSize:"24px",fontWeight:"700",letterspacing:"normal",lineHeight:"120%",textalign:"left",marginTop:"0",marginBottom:"0"}}>
							<span className="tinyMce-placeholder">Providing resources for Higher Education</span> </h3>
					</div>
					<div className="block block-4 paragraph">
						<p>Our organization offers a wide range of resources to support higher education, including access to educational materials, mentorship programs, and networking opportunities. We are committed to helping students achieve their academic and career goals.</p>
					</div>
				</div>
				<div className="cols cols-2 cols-w6">
					<div className="block block-1 image"><a href="https://www.example.com" target="_self"><img
								alt="smiling girl with computer" className="center autowidth"
								src="images/happy-ethnic-woman-sitting-at-table-with-laptop-3769021.jpg"
								style={{maxWidth:"720px"}} /></a></div>
				</div>
			</div>
		</div>
		<div className="rows rows-22">
			<div className="rows-content reverse">
				<div className="cols cols-1 cols-w4">
					<div className="block block-1 heading">
						<h1
							style={{color:"#ffffff",direction:"ltr",fontFamily:'Noto Serif',fontSize:"40px",fontWeight:"700",letterSpacing:"normal",lineHeight:"120%",textalign:"left"}}>
							<span className="tinyMce-placeholder">Contact Info</span> </h1>
					</div>
					<div className="block block-2 paragraph">
						<p>UTA<br /></p>
					</div>
					<div className="block block-3 icons">
						<div className="icon icon-last">
							<div className="content">
								<div className="icon-image"><img height="16px" src="images/email-icon.png" width="auto" />
								</div>
								<div className="icon-label icon-label-right">info@volunteerconnect.com</div>
							</div>
						</div>
					</div>
					<div className="block block-4 icons">
						<div className="icon icon-last">
							<div className="content">
								<div className="icon-image"><img height="32px" src="images/phone-icon.png" width="auto" />
								</div>
								<div className="icon-label icon-label-right">+1235655555</div>
							</div>
						</div>
					</div>
					
				</div>
				<div className="cols cols-2 cols-w8">
					<div className="block block-1 heading">
						<h1
							style={{color:"#ffffff",direction:"ltr",fontFamily:'Noto Serif',fontSize:'40px',fontWeight:"700",letterSpacing:"normal",lineHeight:"120%" ,textalign:"left" ,marginTop:"0" ,marginBottom:"0"}}>
							<span className="tinyMce-placeholder">Leave your message</span> </h1>
					</div>
					<div className="block block-2 form" id="form">
						<form accept-charset="UTF-8" action="ACTION_PLACEHOLDER" autocomplete="on"
							enctype="multipart/form-data" method="post" target="_self">
							<div className="form-rows">
								<div className="field field-r21c1m1i1"><input id="r21c1m1i1" name="firstname"
										placeholder="Name and surname" required="" type="text" /></div>
							</div>
							<div className="form-rows">
								<div className="field field-r21c1m1i3"><input id="r21c1m1i3" name="email"
										placeholder="Your Email" required="" type="text" /></div>
							</div>
							<div className="form-rows">
								<div className="field field-r21c1m1i7"><textarea id="r21c1m1i7" name="message"
										placeholder="Your message"></textarea></div>
							</div>
							<div className="form-rows">
								<div className="field field-r21c1m1i11">
									<div className="button-container"><button id="r21c1m1i11" name="submit" type="submit"
											value="SEND MESSAGE">SEND MESSAGE</button></div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<div className="rows rows-23">
			<div className="rows-content">
				<div className="cols cols-2 cols-w10">
					<div className="block block-1 paragraph">
						<p>Copyright © 2024 Volunteer Connect, All rights reserved.</p>
					</div>
				</div>
			</div>
		</div>
        </div>
	</>	

    );
}

export default Home;
