import React,{useEffect} from 'react'
import '../../src/styles.css';
import ProfessorHeader from './ProfessorHeader';
import Chart from 'chart.js/auto'; // Import Chart.js

function ProfessorsDashboard() {
    useEffect(() => {
        // Sample data for task completion
        const taskCompletionData = [70, 30, 50, 80, 90];

        // Task Completion Chart
        var taskCompletionChart = new Chart(document.getElementById('taskCompletionChart'), {
            type: 'bar',
            data: {
                labels: ['Task 1', 'Task 2', 'Task 3', 'Task 4', 'Task 5'],
                datasets: [{
                    label: 'Task Completion (%)',
                    data: taskCompletionData,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Sample data for report quality
        const reportQualityData = [4, 3, 5, 4, 3];

        // Report Quality Chart
        var reportQualityChart = new Chart(document.getElementById('reportQualityChart'), {
            type: 'bar',
            data: {
                labels: ['Report 1', 'Report 2', 'Report 3', 'Report 4', 'Report 5'],
                datasets: [{
                    label: 'Report Quality (Rating)',
                    data: reportQualityData,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 5 // Assuming the rating scale is from 1 to 5
                    }
                }
            }
        });

        return () => {
            // Cleanup code to destroy the charts
            taskCompletionChart.destroy();
            reportQualityChart.destroy();
        };
    }, []);
  return (
<>
<ProfessorHeader/>
<main className="container">
    <h2>Task Assignment</h2>
        
    <section className="task-assignment chart-container">
        <div className="chart">
        <div className="box ">
            <h3>Task 1</h3>
            <p>Deadline: 03/20/2024</p>
            <p>Priority: High</p>
        </div>
        <div className="box ">
            <h3>Task 2</h3>
            <p>Deadline: 03/25/2024</p>
            <p>Priority: Medium</p>
        </div>
        </div>
        <div className="chart">
            <img src={"image1_0.jpg"} alt="" style={{width: "100%",height:"auto"}}/>
        </div>
    </section>

    <section className="report-review">
        <h2>Report Review</h2>
        <div className="chart-container">
        <div className="box chart">
            <h3>Weekly Report - Week 1</h3>
            <p>Submitted by: Graduate A</p>
            <p>Content: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed id ligula et nisi efficitur rutrum.</p>
            <p>Feedback: Excellent work!</p>
        </div>
        <div className="box chart">
            <h3>Weekly Report - Week 2</h3>
            <p>Submitted by: Graduate B</p>
            <p>Content: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed id ligula et nisi efficitur rutrum.</p>
            <p>Feedback: Good effort.</p>
        </div>
    </div>
    </section>

    <section className="charts">
        <h2>Charts</h2>
        <div className="chart-container">
            <div className="chart">
                <canvas id="taskCompletionChart" width="400" height="200"></canvas>
            </div>
            <div className="chart">
                <canvas id="reportQualityChart" width="400" height="200"></canvas>
            </div>
        </div>
    </section>
    <section>
        <table className="table display product-overview mb-30" id="support_table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Task</th>
                    <th>Assigned Professors</th>
                    <th>status</th>
                    <th>Progress</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Preparation for cricket team</td>
                    <td>Kenny Josh</td>
                    <td>
                        <span className="label label-sm label-success">Done</span>
                    </td>
                    <td>
                        <div className="progress1">
                            <div className="progress1-bar progress1-bar-success progress1-bar-striped active" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style={{width:"100%"}}> <span className="sr-only">100%
                                    Complete</span> </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Annual function preparation</td>
                    <td> Mark</td>
                    <td>
                        <span className="label label-sm label-warning"> Pending </span>
                    </td>
                    <td>
                        <div className="progress1">
                            <div className="progress1-bar progress1-bar-warning progress1-bar-striped active" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style={{width:"50%"}}> <span className="sr-only">70%
                                    Complete</span> </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Final year exam paper set</td>
                    <td>Felix </td>
                    <td>
                        <span className="label label-sm label-danger">Suspended</span>
                    </td>
                    <td>
                        <div className="progress1">
                            <div className="progress1-bar progress1-bar-danger progress1-bar-striped active" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style={{width:"50%"}}> <span className="sr-only">50%
                                    Complete</span> </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>Placement report</td>
                    <td>Beryl</td>
                    <td>
                        <span className="label label-sm label-success ">Done</span>
                    </td>
                    <td>
                        <div className="progress1">
                            <div className="progress1-bar progress1-bar-success progress1-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style={{width:"100%"}}> <span className="sr-only">100%
                                    Complete</span> </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>Fees collection report</td>
                    <td>Jayesh</td>
                    <td>
                        <span className="label label-sm label-success ">Done</span>
                    </td>
                    <td>
                        <div className="progress1">
                            <div className="progress1-bar progress1-bar-success progress1-bar-striped active" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style={{width:"100%"}}> <span className="sr-only">100%
                                    Complete</span> </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>Library book status</td>
                    <td>Sharma</td>
                    <td>
                        <span className="label label-sm label-danger">Suspended</span>
                    </td>
                    <td>
                        <div className="progress1">
                            <div className="progress1-bar progress1-bar-danger progress1-bar-striped active" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style={{width:"20%"}}> <span className="sr-only">20%
                                    Complete</span> </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>8</td>
                    <td>Exam Paper set</td>
                    <td>John Deo</td>
                    <td>
                        <span className="label label-sm label-warning"> Pending </span>
                    </td>
                    <td>
                        <div className="progress1">
                            <div className="progress1-bar progress1-bar-warning progress1-bar-striped active" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style={{width:"80%"}}> <span class="sr-only">80%
                                    Complete</span> </div>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </section>
</main>

<footer>
    <p>&copy; 2024 Professor Dashboard. All rights reserved.</p>
</footer>
</>
  )
}

export default ProfessorsDashboard