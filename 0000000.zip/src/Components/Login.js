import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from './Header';
import LogoutButton from './LogoutButton'; // Import the LogoutButton component
import '../../src/style.css';

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false); // Track login status
  const navigate = useNavigate();

  useEffect(() => {
    if (isLoggedIn) {
      if (email === 'professor@volunteerconnect.com' && password === 'professorpassword') {
        navigate('/professordashboard');
      } else if (email === 'graduate@volunteerconnect.com' && password === 'graduatepassword') {
        navigate('/graduatedashboard');
      }
      else
      {
        alert('Invalid Credentials')
      }
    }
  }, [isLoggedIn, email, password, navigate]);

  const handleLogin = () => {
    // Perform login logic here
    // For now, just update the isLoggedIn state
    setIsLoggedIn(true); // Set login status to true
  };

  const handleEmailChange = (e) => {
    setEmail(e.target.value); // Update the email state based on input field value
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value); // Update the password state based on input field value
  };

  return (
    <>
      <Header />
      <div className="container" style={{ background: "url()", backgroundRepeat: "no-repeat", backgroundSize: "cover" }}>
        <div className="login_form" >
          <div style={{ marginBottom: "auto", marginTop: "auto" }}>
            <div className="login_box">
              <div className="box-title">
                <h4 className="text-align-center login_box_title">Login</h4>
              </div>
              <div style={{ marginBottom: "1rem" }}>
                <input type="email" name="email" placeholder="user@volunteerconnect.com" value={email} onChange={handleEmailChange} />
                <small style={{ color: "#6c757d!important", display: "block", marginTop: "0.25rem", fontSize: "80%", fontWeight: 400 }}>We'll never share your email with anyone else</small>
              </div>
              <div style={{ marginBottom: "1rem" }}>
                <input type="password" name="password" placeholder="password" value={password} onChange={handlePasswordChange} />
              </div>
              <button type="button" onClick={handleLogin} className="login_button" style={{ backgroundColor: "#0069d9", borderColor: " #0062cc" }}>Submit</button>
              {/* Conditionally render LogoutButton if user is logged in */}
              {isLoggedIn && <LogoutButton />}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Login;
