import logo from './logo.svg';
// import './App.css';
import {BrowserRouter as Router,Routes,Route, useNavigate}  from 'react-router-dom';

import Home from './Components/Home';
import About from './Components/About';
import Login from './Components/Login';
import Register from './Components/Register';
import ContactUs from './Components/ContactUs';
import Services from './Components/Services';
import AntiCheating from './Components/AntiCheating';
import GraduateCalendar from './Components/GraduateCalendar';
import GraduateDashboard from './Components/GraduateDashboard';
import GraduateProgress from './Components/GraduateProgress';
import GraduateTasks from './Components/GraduateTasks';
import GraduateWeeklyReports from './Components/GraduateWeeklyReports';
import ProfessorFeedback from './Components/ProfessorFeedback';
import ProfessorReports from './Components/ProfessorReports';
import ProfessorsDashboard from './Components/ProfessorsDashboard';
import ProfessorTask from './Components/ProfessorTask';
import TaskStatusUpdates from './Components/TaskStatusUpdates';
import TaskSubmission from './Components/TaskSubmission';
import TaskView from './Components/TaskView';
import WeeklyReports from './Components/WeeklyReports';

function App() {
  return (
    <div className="App">
    <Router>
      <Routes>
        <Route path="/" element={<Home />}/>
        <Route path="/login" element={<Login />}/>
        <Route path="/register" element={<Register />}/>
        <Route path="/about" element={<About />}/>
        <Route path="/contact" element={<ContactUs />}/>
        <Route path="/service" element={<Services />}/>
        <Route path="/anticheating" element={<AntiCheating />}/>
        <Route path="/graduatecalendar" element={<GraduateCalendar />}/>
        <Route path="/graduatedashboard" element={<GraduateDashboard />}/>
        <Route path="/graduateprogress" element={<GraduateProgress/>}/>
        <Route path="/graduatetasks" element={<GraduateTasks />}/>
        <Route path="/graduateweeklyreports" element={<GraduateWeeklyReports />}/>
        <Route path="/professorfeedback" element={<ProfessorFeedback />}/>
        <Route path="/professorreports" element={<ProfessorReports />}/>
        <Route path="/professordashboard" element={<ProfessorsDashboard />}/>
        <Route path="/professortask" element={<ProfessorTask/>}/>
        <Route path="/taskstatusupdates" element={<TaskStatusUpdates />}/>
        <Route path="/tasksubmission" element={<TaskSubmission />}/>
        <Route path="/taskview" element={<TaskView/>}/>
        <Route path="/weeklyreports" element={<WeeklyReports />}/>




        </Routes>
        </Router>
        </div>
  );
}

export default App;
