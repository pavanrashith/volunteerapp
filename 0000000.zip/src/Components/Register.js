import React, { useState } from 'react';
import Header from './Header';
import '../../src/style.css';

function Register() {
    const [userName, setUserName] = useState('');
    const [mobile, setMobile] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = () => {
        // Basic validation to check if required fields are not empty
        if (!userName || !mobile || !email || !password) {
            alert('Please fill in all fields.');
            return;
        }

        // Email validation
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            alert('Please enter a valid email address.');
            return;
        }

        // Password validation
        if (password.length < 8) {
            alert('Password must be at least 6 characters long.');
            return;
        }

        // Mobile number validation
        const mobilePattern = /^\d{10}$/;
        if (!mobilePattern.test(mobile)) {
            alert('Please enter a valid 10-digit mobile number.');
            return;
        }

        // Additional validation logic can be added here

        // If all fields are filled and validations pass, proceed with registration
        alert('Registration successful!');
    };

    return (
        <>
            <Header />
            <div className="container" style={{ background: "url(https://www.freepik.com/free-vector/hand-drawn-back-school-background_28480371.htm#query=education%20background&position=2&from_view=keyword&track=ais&uuid=17947a86-b98d-44b8-a08c-56bd11b65262)", backgroundRepeat: "no-repeat", backgroundSize: "cover" }}>
                <div className="login_form">
                    <div style={{ marginBottom: "auto ", marginTop: " auto" }}>
                        <div className="login_box">
                            <div className="box-title">
                                <h4 className="text-align-center login_box_title">Register</h4>
                            </div>
                            <div style={{ marginBottom: "1rem" }}>
                                <input type="text" name="username" placeholder="User Name" value={userName} onChange={(e) => setUserName(e.target.value)} />
                            </div>
                            <div style={{ marginBottom: "1rem" }}>
                                <input type="text" name="mobile" placeholder="Mobile" value={mobile} onChange={(e) => setMobile(e.target.value)} />
                            </div>
                            <div style={{ marginBottom: "1rem" }}>
                                <input type="text" name="email" placeholder="user@volunteerconnect.com" value={email} onChange={(e) => setEmail(e.target.value)} />
                                <small style={{ color: "#6c757d", display: " block", marginTop: "0.25rem", fontSize: "80%", fontSize: "80%", fontWeight: "400" }}>We'll never share your email with anyone else</small>
                            </div>
                            <div style={{ marginBottom: "1rem" }}>
                                <input type="password" name="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
                            </div>
                            <button type="button" onClick={handleSubmit} className="login_button">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Register;
