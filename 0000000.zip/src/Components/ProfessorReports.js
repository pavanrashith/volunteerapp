import React from 'react'
import '../../src/styles.css';
import ProfessorHeader from './ProfessorHeader';

function ProfessorReports() {
  return(
 <>

<ProfessorHeader/>
<main className="container">
    <section className="report-review">
     <div className="report">
            <h3>Weekly Report - Week 1</h3>
            <p>Submitted by: Graduate A</p>
            {/* <p>Content: Lorem ipsum dolor sit amet...</p> */}
            <form>
                <label for="feedback">Report Review:</label>
                <textarea id="feedback" name="feedback" rows="4" cols="50" required></textarea>
                <button type="submit">Submit Review</button>
            </form>
        </div>
    </section>
</main>

<footer>
    <p>&copy; 2024 Professor's Dashboard. All rights reserved.</p>
</footer>
</>
  )
}


export default ProfessorReports