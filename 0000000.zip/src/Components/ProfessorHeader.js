import React from 'react';
import { Link } from 'react-router-dom';
import LogoutButton from './LogoutButton';

function ProfessorHeader() {
  return (
    <div className="rows rows-2">
      <div className="rows-content no_stack">
        <div className="cols cols-1 cols-w4">
          <div className="block block-1 image">
            <Link to="/">
              <img
                alt="Your logo"
                className="fixedwidth"
                src="logo.jpeg"
                style={{ maxWidth: "50px" }}
              />
            </Link>
          </div>
        </div>
        <div className="cols cols-2 cols-w8">
          <div className="block block-1 menu">
            <nav className="menu">
              <input className="hamburger-trigger" id="hamburger-memu-r1c1m0" type="checkbox" />
              <label className="hamburger-controls" htmlFor="hamburger-memu-r1c1m0">
                <span className="hamburger-open"></span>
                <span className="hamburger-close"></span>
              </label>
              <ul className="horizontal with-hamburger">
                <li><Link to="/professordashboard" title="Home">Home</Link></li>
                <li><Link to="/professortask" title="Tasks">Tasks</Link></li>
                <li><Link to="/professorreports" title="Report Review">Report Review</Link></li>
                <li><Link to="/professorfeedback" title="Feedback">Feedback</Link></li>
                <li><LogoutButton /></li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProfessorHeader;
