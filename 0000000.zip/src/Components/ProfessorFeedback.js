import React from 'react'
import '../../src/styles.css';
import ProfessorHeader from './ProfessorHeader';

function ProfessorFeedback() {
  return (
    <>
<ProfessorHeader/>

<main className="container">
    <section className="feedback">
        <div className="report">
            <h3>Weekly Report - Week 1</h3>
            <p>Submitted by: Graduate A</p>
            {/* <p>Content: Lorem ipsum dolor sit amet...</p> */}
            <form action="submit_feedback.php" method="post">
                <label for="feedback">Feedback:</label>
                <textarea id="feedback" name="feedback" rows="4" cols="50" required></textarea>
                <button type="submit">Submit Feedback</button>
            </form>
        </div>
    </section>
</main>

<footer>
    <p>&copy; 2024 Professor's Dashboard. All rights reserved.</p>
</footer>
</>
  )
}

export default ProfessorFeedback