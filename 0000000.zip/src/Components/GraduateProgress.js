import React from 'react'
import '../../src/styles.css';
import GraduateHeader from './GraduateHeader';

function GraduateProgress() {
  return (
    <>
    <GraduateHeader/>
    

<main className="container">
    <section className="progress">
        <h2>Progress Tracking</h2>
        <p>Total tasks completed: <span id="tasksCompleted">10</span></p>
        <p>Total hours worked: <span id="totalHoursWorked">100</span></p>
        <p>Upcoming deadlines: <span id="upcomingDeadlines">05/10/2024</span></p>
    </section>
</main>

<footer>
    <a href="calendar.html">View Calendar</a>
    <a href="weekly_reports.html">View Weekly Reports</a>
</footer>
</>
  )
}

export default GraduateProgress